from bs4 import BeautifulSoup
import requests
import re
from MaltegoTransform import *

def deCFEmail(fp):
    r = int(fp[:2],16)
    email = ''.join([chr(int(fp[i:i+2], 16) ^ r) for i in range(2, len(fp), 2)])
    return email

me = MaltegoTransform()
me.parseArguments(sys.argv)

section = sys.argv[1]
entity = sys.argv[2]
args = sys.argv[3]

if section == "list_matches":
	name = sys.argv[2]
	first_name = name.split(' ')[0]
	try:
		if name.split(' ')[2]:
			last_name = name.split(' ')[2]
	except:
		last_name = name.split(' ')[1]

	base_url = 'https://www.truepeoplesearch.com'

	try:
		address = args.split("Address=")[1]
	except:
		address = None

	if address is not None:
		city = address.split(',')[0]
		state = address.split(',')[1]
		r = requests.get(base_url + '/results?name=' + first_name + '%20' + last_name + '&citystatezip=' + city + ',%20' + state)
	else:
		r = requests.get(base_url + '/results?name=' + first_name + '%20' + last_name)

	page = r.content
	soup = BeautifulSoup(page, "html.parser")

	addresses = soup.find_all(class_="card-summary")

	for t in addresses:
		location = t.find_all(class_="content-value")[1].get_text()
		ent = me.addEntity("maltego.Person",first_name + " " + last_name + "\n" + location)
		ent.addAdditionalFields('url','url','',base_url + t['data-detail-link'])
else:
	url = args.split("url=")[1]
	url = url.replace("\\", "")

	r = requests.get(url)
	page = r.content
	soup = BeautifulSoup(page, "html.parser")

if section == "current_address":
	addresses = soup.find_all(attrs={"data-link-to-more":"address"})
	ent = me.addEntity("maltego.Location",addresses[0].get_text())

elif section == "previous_address":
	addresses = soup.find_all(attrs={"data-link-to-more":"address"})
	for addr in addresses:
		ent = me.addEntity("maltego.Location",addr.get_text())

elif section == "phone_number":
	phone_numbers = soup.find_all(attrs={"data-link-to-more":"phone"})
	for number in phone_numbers:
		ent = me.addEntity("maltego.PhoneNumber",number.get_text())

elif section == "email_address":
	email_addresses = soup.find_all(attrs={"class":"__cf_email__"})
	for addr in email_addresses:
		email = deCFEmail(addr['data-cfemail'])
		ent = me.addEntity("maltego.EmailAddress",email)

elif section == "relatives":
	relatives = soup.find_all(attrs={"data-link-to-more":"relative"})
	for relative in relatives:
		ent = me.addEntity("maltego.Person",relative.get_text())

elif section == "associates":
	associates = soup.find_all(attrs={"data-link-to-more":"associate"})
	for associate in associates:
		ent = me.addEntity("maltego.Person",associate.get_text())

elif section == "business":
	test = soup.find_all(attrs={"style":"padding-bottom:6px;"})
	for t in test:
		if t.find(class_="link-to-more"):
			pass
		elif t.find(class_="__cf_email__"):
			pass
		else:
			ent = me.addEntity("maltego.Location",t.get_text())

me.returnOutput()